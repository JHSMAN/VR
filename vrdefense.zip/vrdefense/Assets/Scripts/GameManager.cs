﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
    public static int score = 0;

    [SerializeField] Text scoretxt;
   // [SerializeField] Text playtimetxt;

    float playtime;

    // Use this for initialization
    void Awake () {
        playtime = 0.0f;
        InvokeRepeating("UpdateTime", 1.0f, 1.0f);
    }

    void UpdateTime()
    {
        playtime += 1.0f;
      //  playtimetxt = string.Format("Playtime", (int)playtime / 60, ":", (int)playtime % 60);
    }
    void Update()
    {
      
        scoretxt.text = "SCORE:" + score.ToString("00000");      //적을 처리하면 점수증가

    }
}
