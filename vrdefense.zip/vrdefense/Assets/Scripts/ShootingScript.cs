﻿using UnityEngine;

public class ShootingScript : MonoBehaviour
{
    public ParticleSystem impactEffect;

    AudioSource gunFireAudio;
    RaycastHit rayHit;

    void Start()
    {

        gunFireAudio = GetComponent<AudioSource>();
        
    }
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            gunFireAudio.Stop();
            gunFireAudio.Play();

            if (Physics.Raycast(transform.position, transform.forward, out rayHit, 100f))
            {
                impactEffect.transform.position = rayHit.point;
                impactEffect.transform.rotation = Quaternion.Euler(270, 0, 0);
                impactEffect.Stop();
                impactEffect.Play();

                if (rayHit.transform.tag == "Enemy")
                    Destroy(rayHit.transform.gameObject);
            }
        }
    }
}
